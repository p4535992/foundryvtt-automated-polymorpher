const CONSTANTS = {
	MODULE_NAME: "automated-polymorpher",
	PATH: `modules/automated-polymorpher/`,
};

CONSTANTS.PATH = `modules/${CONSTANTS.MODULE_NAME}/`;

export default CONSTANTS;

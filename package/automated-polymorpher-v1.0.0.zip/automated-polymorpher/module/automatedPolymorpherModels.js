export class SystemCreatures {
}
// export class Creatures {
//   [key: string]: Creature[]|FunctionCreature;
// }
export class Creature {
}
// export class CreatureData{
//   animation:string;
//   level:number;
// }
// const createCreature = function(data:CreatureData):Creature[]{
//   return [];
// }
// type FunctionCreature = ReturnType<typeof createCreature>

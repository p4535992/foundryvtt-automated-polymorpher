export class SystemCreatures {
}
// export class Creatures {
//   [key: string]: Creature[]|FunctionCreature;
// }
export class Creature {
}
// export class CreatureData{
//   animation:string;
//   level:number;
// }
// const createCreature = function(data:CreatureData):Creature[]{
//   return [];
// }
// type FunctionCreature = ReturnType<typeof createCreature>
export var PolymorpherFlags;
(function (PolymorpherFlags) {
    PolymorpherFlags["IS_LOCAL"] = "isLocal";
    PolymorpherFlags["STORE_ON_ACTOR"] = "storeonactor";
    PolymorpherFlags["POLYMORPHERS"] = "polymorphers";
})(PolymorpherFlags || (PolymorpherFlags = {}));
export class PolymorpherData {
}
